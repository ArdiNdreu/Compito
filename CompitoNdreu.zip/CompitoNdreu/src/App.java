public class App {
    public static void main(String[] args) throws Exception {


        Semaforo semaforo=new Semaforo(2);
        Monoposto m=new Monoposto(2,"ferrari","giorgio",semaforo);
        Monoposto m1=new Monoposto(23,"RedBull","fernando",semaforo);
        Monoposto m2=new Monoposto(49,"Mercedes","maradona",semaforo);

       m.start();
       m1.start();
       m2.start();

       m.join();
       m1.join();
       m2.join();
   

       System.out.println("fine gara");

    }
}

