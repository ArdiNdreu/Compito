public class Monoposto extends Thread{
    
    private int identicativo;
    private String scuderia;
    private String nome;
    private Semaforo ss;
   
    public Monoposto(int id,String s,String n,Semaforo ss){

     
       this.identicativo=id;
       this.scuderia=s;
       this.nome=n;
       this.ss=ss;

       this.setName(n);

    }
   


    @Override
    public void run(){

      int cont=1;
      
      System.out.println(Thread.currentThread().getName()+"ha iniziato la gara");

     
   
        try {
    

        for(int i=1;i<10;i++){

      int giro= (int) (Math.random()*4000+1000);
        
    Thread.sleep(giro);

      System.out.println(Thread.currentThread().getName()+"   ha finito il" +i+"   giro");
        
      cont++;
      
      
      if(cont==3){
        System.out.println(Thread.currentThread().getName()+" cambio gomme in corso");
       
        ss.p();
        ss.v();
      }

        }} catch (Exception e) {
     System.out.println(e.getMessage());
}
    }




}
