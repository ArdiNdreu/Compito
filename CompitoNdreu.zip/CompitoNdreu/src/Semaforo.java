import java.util.ArrayList;

public class Semaforo {
    

    private int value;
    private ArrayList <Monoposto> listamono= new ArrayList();

    public Semaforo(int value){

       this.value=value;

    }


    public synchronized void p(){

        
        while(value==0){
    
            int gomme=(int) (Math.random()*5+1);
      
            System.out.println("pit stop"+ Thread.currentThread().getName()+"cambio gomme in corso");
      
            try {
                int alettuccio=(int) (Math.random()*5+1);
                listamono.add((Monoposto) Thread.currentThread());
                Thread.sleep(alettuccio);
                if(listamono.size()==1){
                    
                    wait();
                    System.out.println(Thread.currentThread().getName()+"sta aspettando al box");
                }
                   
                }
                

            catch (Exception e) {
               System.out.println(e.getMessage());
            }

        }





    }



    public synchronized void v(){

        value++;
        notifyAll();
    }
}
